﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleSolver
{
    public interface IConsoleManager
    {
        void RunProgram(string[] pathToFile);


    }
}
